class CustomError extends Error {
    constructor(message) {
        super(message);
        this.name = 'CustomError';
    }
}

function throwGenericError() {
    throw new Error('Generic error');
}

function throwCustomError() {
    throw new CustomError('Custom error');
}

try {
    console.log('try throwGenericError()');
    throwGenericError();
} catch (e) {
    console.log('Caught an error:', e.message);
} finally {
    console.log('Finally generic error');
}

try {
    console.log('try throwCustomError()');
    throwCustomError();
} catch (e) {
    console.log('Caught a custom error:', e.message);
} finally {
    console.log('Finally custom error');
}
